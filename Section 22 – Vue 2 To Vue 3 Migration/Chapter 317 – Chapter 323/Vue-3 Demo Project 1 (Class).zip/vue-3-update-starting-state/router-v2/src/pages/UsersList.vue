<template>
  <div class="container">
    <h2>Our Users</h2>
    <ul>
      <li>Max</li>
      <li>Manuel</li>
      <li>Julie</li>
    </ul>
  </div>
</template>