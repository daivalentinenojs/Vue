import { createApp } from 'vue';

import App from './App.vue';

// Add Vuex!

createApp(App).mount('#app');
