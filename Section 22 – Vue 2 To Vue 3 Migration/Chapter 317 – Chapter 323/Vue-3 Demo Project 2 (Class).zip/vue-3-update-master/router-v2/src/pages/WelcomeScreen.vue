<template>
  <div class="container">
    <h2>Welcome to this app!</h2>
  </div>
</template>