import { createApp } from 'vue';

import App from './App.vue';

// Add router!

createApp(App).mount('#app');
