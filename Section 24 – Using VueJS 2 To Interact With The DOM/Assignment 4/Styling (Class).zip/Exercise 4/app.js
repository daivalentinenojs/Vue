new Vue({
  el: '#exercise',
  data: {

  },
  methods: {
    startEffect: function() {
    
    }
  }
});
